MiPanel V2
==========
Prototipo funcional en un solo archivo HTML.

Incluye:
- Registro e inicio de sesión de demostración.
- Catálogo de servicios.
- Creación de pedidos.
- Estados de pedidos.
- Saldo de demostración.
- Panel administrador.
- Alta/activación/desactivación de servicios.
- Datos guardados en localStorage del navegador.

Cuenta de administrador de DEMOSTRACIÓN:
Correo: admin@demo.local
Contraseña: demo123

IMPORTANTE:
Esto todavía NO es un sistema online real ni un sistema seguro de autenticación.
No uses esta versión para guardar contraseñas reales ni cobrar dinero real.
El siguiente paso será conectar una base de datos/autenticación real y después un sistema de pagos adecuado.

Los servicios de ejemplo son servicios digitales legítimos (diseño y edición), no manipulación de métricas ni cuentas.
